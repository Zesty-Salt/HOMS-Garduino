/*
    The HOMS arduino-powered garden is an open project (for now)
    that promotes creativity, problem solving, and teamwork for 
    the next generation.
    
    The HOMS Robotics Team:
    = Coders:
    Riley Eisel (Main)

    = Engineers:
    
    Created: 5/17/2019
    Last Revision: 5/17/2019 11:05AM

    This code is in the public domain.
*/

/* - - -  Adjust these variables ONLY!!  - - - */

// Sensor trial settings
const int number_of_trials = 5;   // # of trials
int trial_data[number_of_trials]; // Where data is stored
int delay_between_trials = 1500;  // Delay between a trial

// Bed wetting system!
bool burst_by_default = true; // Use burst watering system
/*
    == If On,

    Valve will turn on for *length_of_burst*,
    Valve will turn off,
    Sensor will take *number_of_trials* readings
    If reached prefered moisture, exit
    Else repeat process

    == If Off,
    
    Sensor will take *number_of_trials* readings
    Valve will turn on for *length_of_reg*,
    Valve will turn off,
    Exit 
*/
int length_of_burst = 5000; // 5 seconds
int length_of_reg = 10000;  // 10 seconds

int garden_check_interval = 3600000;    // 1 hour
int lcd_graphic_change_interval = 5000; // 5 seconds
/* - - -             End                 - - - */

// Moisture sensor pins
#define moisture_bed1 A1 // Analog 1
#define moisture_bed2 A2 // Analog 2
#define moisture_bed3 A3 // Analog 3
#define moisture_bed4 A4 // Analog 4

// Temperature sensor pins
#define temperature_bed1 A5 // Analog 5
#define temperature_bed2 A6 // Analog 6
#define temperature_bed3 A7 // Analog 7
#define temperature_bed4 A8 // Analog 8

// Light level sensors
#define light_bed1 A9  // Analog 9
#define light_bed2 A10 // Analog 10
#define light_bed3 A11 // Analog 11
#define light_bed4 A12 // Analog 12

// Utilities
#define relay_bed1 34 // Digital 34
#define relay_bed2 35 // Digital 35
#define relay_bed3 36 // Digital 36
#define relay_bed4 37 // Digital 37

#define ir_sensor 23 // Digital 23

// Library variables
// IR remote
IRrecv irrecv(ir_sensor);
IRsend irsend;
decode_results results;

// LCD display
const int rs = 12, en = 11, d4 = 5, d5 = 4, d6 = 3, d7 = 2;
LiquidCrystal lcd(rs, en, d4, d5, d6, d7);